package com.example.practica_01

data class Alumno (val nombre: String, val cuenta:String, val correo: String,val image: String)